create function st_pixelaspoints(rast raster, band integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, OUT geom geometry, OUT val double precision, OUT x integer, OUT y integer)
  returns SETOF record
immutable
strict
parallel safe
language sql
as $$
SELECT public.ST_PointN(  public.ST_ExteriorRing(geom), 1), val, x, y FROM public._ST_pixelaspolygons($1, $2, NULL, NULL, $3)
$$;

comment on function st_pixelaspoints(raster, integer, boolean, out geometry, out double precision, out integer,
                                                               out integer)
is 'args: rast, band=1, exclude_nodata_value=TRUE - Returns a point geometry for each pixel of a raster band along with the value, the X and the Y raster coordinates of each pixel. The coordinates of the point geometry are of the pixels upper-left corner.';

alter function st_pixelaspoints(raster, integer, boolean, out geometry, out double precision, out integer, out integer)
  owner to postgres;

