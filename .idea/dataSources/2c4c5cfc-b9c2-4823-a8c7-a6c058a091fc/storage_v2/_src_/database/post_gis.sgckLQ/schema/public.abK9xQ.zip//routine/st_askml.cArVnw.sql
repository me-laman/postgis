create function st_askml(version integer, geom geometry, maxdecimaldigits integer DEFAULT 15, nprefix text DEFAULT NULL::text)
  returns text
immutable
parallel safe
language sql
as $$
SELECT public._ST_AsKML($1, public.ST_Transform($2,4326), $3, $4);
$$;

comment on function st_askml(integer, geometry, integer, text)
is 'args: version, geom, maxdecimaldigits=15, nprefix=NULL - Return the geometry as a KML element. Several variants. Default version=2, default precision=15';

alter function st_askml(integer, geometry, integer, text)
  owner to postgres;

