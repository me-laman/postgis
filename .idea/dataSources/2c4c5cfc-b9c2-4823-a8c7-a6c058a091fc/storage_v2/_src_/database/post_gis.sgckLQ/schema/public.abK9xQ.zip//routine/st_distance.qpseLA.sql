create function st_distance(geography, geography, boolean)
  returns double precision
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_Distance($1, $2, 0.0, $3)
$$;

comment on function st_distance(geography, geography, boolean)
is 'args: gg1, gg2, use_spheroid - For geometry type Returns the 2D Cartesian distance between two geometries in projected units (based on spatial ref). For geography type defaults to return minimum geodesic distance between two geographies in meters.';

alter function st_distance(geography, geography, boolean)
  owner to postgres;

