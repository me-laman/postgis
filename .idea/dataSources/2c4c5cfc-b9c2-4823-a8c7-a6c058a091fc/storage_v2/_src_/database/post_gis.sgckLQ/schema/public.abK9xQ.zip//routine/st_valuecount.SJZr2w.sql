create function st_valuecount(rast raster, nband integer, searchvalues double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT count integer)
  returns SETOF record
immutable
parallel safe
language sql
as $$
SELECT value, count FROM public._ST_valuecount($1, $2, TRUE, $3, $4)
$$;

comment on function st_valuecount(raster, integer, double precision [], double precision, out double precision,
                                                                                          out integer)
is 'args: rast, nband, searchvalues, roundto=0, OUT value, OUT count - Returns a set of records containing a pixel band value and count of the number of pixels in a given band of a raster (or a raster coverage) that have a given set of values. If no band is specified defaults to band 1. By default nodata value pixels are not counted. and all other values in the pixel are output and pixel band values are rounded to the nearest integer.';

alter function st_valuecount(raster, integer, double precision [], double precision, out double precision, out integer)
  owner to postgres;

