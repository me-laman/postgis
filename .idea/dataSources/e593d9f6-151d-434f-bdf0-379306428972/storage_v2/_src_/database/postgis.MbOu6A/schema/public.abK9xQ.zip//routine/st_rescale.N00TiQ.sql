create function st_rescale(rast raster, scalex double precision, scaley double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125)
  returns raster
stable
strict
language sql
as $$
SELECT  public._ST_GdalWarp($1, $4, $5, NULL, $2, $3)
$$;

comment on function st_rescale(raster, double precision, double precision, text, double precision)
is 'args: rast, scalex, scaley, algorithm=NearestNeighbour, maxerr=0.125 - Resample a raster by adjusting only its scale (or pixel size). New pixel values are computed using the NearestNeighbor (english or american spelling), Bilinear, Cubic, CubicSpline or Lanczos resampling algorithm. Default is NearestNeighbor.';

alter function st_rescale(raster, double precision, double precision, text, double precision)
  owner to postgres;

