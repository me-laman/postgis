create function st_tile(rast raster, width integer, height integer, padwithnodata boolean DEFAULT false, nodataval double precision DEFAULT NULL::double precision)
  returns SETOF raster
immutable
parallel safe
language sql
as $$
SELECT public._ST_tile($1, $2, $3, NULL::integer[], $4, $5)
$$;

comment on function st_tile(raster, integer, integer, boolean, double precision)
is 'args: rast, width, height, padwithnodata=FALSE, nodataval=NULL - Returns a set of rasters resulting from the split of the input raster based upon the desired dimensions of the output rasters.';

alter function st_tile(raster, integer, integer, boolean, double precision)
  owner to postgres;

